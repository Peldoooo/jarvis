"""
Camera module initialization
"""

from .camera_manager import CameraManager

__all__ = ['CameraManager']
