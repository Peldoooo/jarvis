"""
Automation module initialization
"""

from .system_control import SystemController

__all__ = ['SystemController']
