"""
Voice module initialization
"""

from .speech_engine import SpeechEngine
from .recognition_engine import RecognitionEngine

__all__ = ['SpeechEngine', 'RecognitionEngine']
