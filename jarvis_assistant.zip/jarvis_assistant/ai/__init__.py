"""
AI module initialization
"""

from .openrouter_client import OpenRouterClient

__all__ = ['OpenRouterClient']
